wget -P ~/Desktop/. http://ecee.colorado.edu/~mathys/ecen4652/lab08/AMsignal_002.bin && wget -P ~/Desktop/. http://ecee.colorado.edu/~mathys/ecen4652/lab08/AMsignal_005.bin
 
